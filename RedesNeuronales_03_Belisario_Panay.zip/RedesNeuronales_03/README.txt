Correr main.py, para obtener los graficos de resultados (aprendizaje y clasificacion) del 
Perceptron y Sigmoid Neuron.

